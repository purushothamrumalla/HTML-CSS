
let minTag=document.getElementById('min');
let secTag=document.getElementById('sec');
let msecTag=document.getElementById('m-sec');
let startBtn=document.getElementById('start-btn');
let stopBtn=document.getElementById('stop-btn');
let resetBtn=document.getElementById('reset-btn');

let min=60;
let sec=60;
let mSec=1000;
let timerRunning=true;


function timer()
{
    mSec=mSec-10;
    if(mSec==0)
    {
        sec=sec-1;
        mSec=1000;
        if(sec===0||sec==60)
        {
            min=min-1;
            sec=59;
        }
    }
    msecTag.innerText=concatZero(mSec);
    secTag.innerText=concatZero(sec);
    minTag.innerText=concatZero(min);    
}


let interval=null;
startBtn.addEventListener('click',function()
{    min=59
    sec=59
    if(timerRunning)
    {
        interval=setInterval(timer,10);
        timerRunning=false;
    }
});

stopBtn.addEventListener('click',function()
{
    if(!timerRunning)
    {
        clearInterval(interval);
        timerRunning=true;
    }
});

resetBtn.addEventListener('click',function()
{
    min=60;
    sec=60;
    mSec=1000;
    timerRunning=true;
    clearInterval(interval);
    secTag.innerText="60";
    msecTag.innerText="00";
    minTag.innerText="00";
})


//Concat Zero

function concatZero(time)
{
    if(time<=9)
    {
        return "0"+time;
    }
    else
    {
        return time;
    }
}
