const key = "761c595d96fd7d4b7942c392e70570ac"
let dis = document.querySelector('.content')
let url = "https://api.openweathermap.org/data/2.5/weather?q={city name}&appid={API key}&units=metric"
let getWeather = async (city) => {
    try {
        let res = await fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${key}&units=metric`)
        let data = await res.json()
        console.log(data);
        let ress=``
        if (data.name) {
            // document.getElementById('cityname').innerHTML=data.name
            // document.getElementById('temp').innerHTML=data.main.temp
            // document.getElementById('hum').innerHTML=data.main.humidity+"%"
            // document.getElementById('wind').innerHTML=data.wind.speed+"Km/Hr"
            ress = `    <img class="mt-3"
                                        src="http://openweathermap.org/img/wn/${data.weather[0].icon}.png"
                                        width="100px" height="100px">
                                    <h1>City : <span style="color:blue">${data.name} </span></h1>
                                    <h3>Temperature : <span style="color:green"> ${data.main.temp}</span>&deg;C</h3>
                                    <table width=100% > 
                                        <tr>
                                            <th>Humidity</th>
                                            <th>Wind</th>
                                        </tr>
                                        <tr>
                                            <td>${data.main.humidity + "%"}</td>
                                            <td>${data.wind.speed + "Km/Hr"}</td>
                                        </tr>
                                    </table>`
            dis.innerHTML = ress
        }
        else {
            dis.innerHTML=ress
            alert("City not found")
        }


    }
    catch (err) {
        console.log(err.data);
    }
}
let tagg = document.getElementById('detail')
tagg.addEventListener("submit", function (e) {
    e.preventDefault()
    let city = document.getElementById('city').value.trim()
    dis.classList.remove('dis')
    if (!city == "")
        getWeather(city)
    else {
        dis.classList.add('dis')
        alert("Enter city name")

    }

})

// function validation() {
//     let city = document.getElementById('city').value.trim()
//     if (city == "") {
//         alert("Enter City name")
//         return false
//     }
//     else {
//         return true
//     }
// }
