let like=document.getElementById('a')
let liked=document.getElementById('b')
let dislike=document.getElementById('c')
let disliked=document.getElementById('d')
let total=document.getElementById('e')
let likes=localStorage.getItem('likes')?localStorage.getItem('likes'):0
let dislikes=localStorage.getItem('dislikes')?localStorage.getItem('dislikes'):0
let totals=localStorage.getItem('totals')?localStorage.getItem('totals'):0

liked.textContent=localStorage.getItem('likes')
localStorage.setItem('likes',likes)

disliked.textContent=localStorage.getItem('dislikes')
localStorage.setItem('dislikes',dislikes)

total.textContent=localStorage.getItem('totals')
localStorage.setItem('totals',totals)

like.addEventListener("click",function(){
    likes++
    totals++
    liked.textContent=likes
    total.textContent=totals
    localStorage.setItem('likes',likes)
    localStorage.setItem('totals',totals)
})
function dis(){
    dislikes++
    totals++
    disliked.textContent=dislikes
    total.textContent=totals
    localStorage.setItem('dislikes',dislikes)
    localStorage.setItem('totals',totals)

}
dislike.addEventListener("click",dis)