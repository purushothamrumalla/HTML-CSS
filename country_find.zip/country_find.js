function country(data) {
    let xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://restcountries.com/v3.1/name/' + data, true);
    xhr.send();
    xhr.addEventListener('load', function () {
        let countries = JSON.parse(xhr.responseText)
        let [data] = countries
        let cer=JSON.stringify(data.currencies)
        console.log(data)
        let temp = `
                <div class="col-6">
                <div class="card">
                    <div class="card-header text-center">
                    <img src="${data.flags.png}" height=200px width=370px >
                    </div>
                        <div class="card-body text-center">
                        <h3>Country Name :  ${data.name.common}</h3> 
                        <h3>Capital  :  ${data.capital[0]}</h3> 
                        <h3> Currency  :  ${cer.slice(2,5)}</h3>
                        <h3>Population  :  ${(data.population/1000000).toFixed(2)} M</h3> 
                    </div>                
                </div>
            </div>
                `
        document.getElementById('display').innerHTML=temp
    })
}
let tagg=document.getElementById('enter_text')
tagg.addEventListener('submit', function (e) {
    e.preventDefault()
    let ctry=document.getElementById('area').value.trim()
    country(ctry)
})