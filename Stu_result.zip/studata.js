let students=[
    {
        id:101,
        name:'Raghu',
        username:"raghu",
        pwd:1111,
        gender:"Male",
        marks:[23,45,56,78,47],
        role:"student"
    },
    {
        id:102,
        name:'Radha',
        username:"radha",
        pwd:2222,
        gender:"Female",
        marks:[78,96,92,67,79],
        role:"student"
    },
    {
        id:103,
        name:'Raja',
        username:"raj",
        pwd:3333,
        gender:"Male",
        marks:[56,89,45,67,81],
        role:"student"
    },
    {
        id:104,
        name:'Sita',
        username:"seetha",
        pwd:4444,
        gender:"Female",
        marks:[47,36,89,73,65],
        role:"student"
    },
    {
        id:105,
        name:'Raghav',
        username:"raghav",
        pwd:4444,
        gender:"Male",
        marks:[47,36,89,73,65],
        role:"Admin"
    }
];

let maxMarks=500;

//total marks
function totalMarks(marks)
{
    let total=0;
    for(let m of marks)
    {
        total=total+m;
    }
    return total;
}

//find percentage

function getPercentage(marks)
{
    let total=totalMarks(marks);
    let percentage=((total/maxMarks)*100).toFixed(0);
    return percentage;
}

//Pass Or Fail

function hasPass(marks)
{
    if(marks[0]<=35||marks[1]<=35||marks[2]<=35||marks[3]<=35||marks[4]<=35)
    {
        return "Fail";
    }
    else
    {
        return "Pass";
    }
}
let pass_btn=document.querySelector('#table-section')


//Display Student Details In Admin Section

function displayStudents(students)
{  
    if(students.length>0)
    {   pass_btn.classList.remove('abc')
        let eachStudent=``;
        students.forEach((student)=>
        {
            let total=totalMarks(student.marks);
            let percentage=getPercentage(student.marks);
            let isPass=hasPass(student.marks);
            eachStudent+=`<tr>
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.gender}</td>
            <td>${percentage}%</td>
            <td>${isPass}</td>
        </tr>`
        });
        document.getElementById('table-section').innerHTML=eachStudent;
    }
}
displayStudents(students);


function pass(){
    pass_btn.classList.remove('abc')
    let eachStudent=``;
        students.forEach((student)=>
        {   
            let total=totalMarks(student.marks);
            let percentage=getPercentage(student.marks);
            let isPass=hasPass(student.marks);
            if(isPass=="Pass"){
            eachStudent+=`<tr>
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.gender}</td>
            <td>${percentage}%</td>
            <td>${isPass}</td>
        </tr>`
            }
        });
        document.getElementById('table-section').innerHTML=eachStudent;
}


function fail(){
    pass_btn.classList.remove('abc')
    let eachStudent=``;
        students.forEach((student)=>
        {   
            let total=totalMarks(student.marks);
            let percentage=getPercentage(student.marks);
            let isPass=hasPass(student.marks);
            if(isPass=="Fail"){
            eachStudent+=`<tr>
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.gender}</td>
            <td>${percentage}%</td>
            <td>${isPass}</td>
        </tr>`
            }
        });
        document.getElementById('table-section').innerHTML=eachStudent;
}
function male(){
    pass_btn.classList.remove('abc')
    let eachStudent=``;
        students.forEach((student)=>
        {   
            let total=totalMarks(student.marks);
            let percentage=getPercentage(student.marks);
            let isPass=hasPass(student.marks);
            if(student.gender=="Male"){
            eachStudent+=`<tr>
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.gender}</td>
            <td>${percentage}%</td>
            <td>${isPass}</td>
        </tr>`
            }
        });
        document.getElementById('table-section').innerHTML=eachStudent;
}
function female(){
    pass_btn.classList.remove('abc')
    let eachStudent=``;
        students.forEach((student)=>
        {   
            let total=totalMarks(student.marks);
            let percentage=getPercentage(student.marks);
            let isPass=hasPass(student.marks);
            if(student.gender=="Female"){
            eachStudent+=`<tr>
            <td>${student.id}</td>
            <td>${student.name}</td>
            <td>${student.gender}</td>
            <td>${percentage}%</td>
            <td>${isPass}</td>
        </tr>`
            }
        });
        document.getElementById('table-section').innerHTML=eachStudent;
}
