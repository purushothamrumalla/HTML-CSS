
let taskEl=document.querySelector('#task-submit');

taskEl.addEventListener('submit',function(e)
{
    e.preventDefault();
    let inputEl=document.querySelector('#input-ele');
    let task=inputEl.value.trim();

    let taskList=localStorage.getItem('tasks')?JSON.parse(localStorage.getItem('tasks')):[];
    taskList.unshift(task);
    localStorage.setItem('tasks',JSON.stringify(taskList));
    displayTasks();
    inputEl.value='';
});

//display Tasks

function displayTasks()
{
    let taskList=localStorage.getItem('tasks')?JSON.parse(localStorage.getItem('tasks')):[];
    let taskListContainer = document.querySelector('#task-list');

    if(taskList.length>0)
    {
        let eachTask=``;
        for(let task of taskList)
        {
            eachTask+=`<li class="list-group-item list-group-item-warning mb-2 m-auto p-auto" style="width:50%">
            <span>${task}
                <button class="close float-end btn-close">
                </button>
            </span>
        </li>`
        }

        document.querySelector('#task-list').innerHTML=eachTask;
    }
}


displayTasks();

let taskele=document.querySelector('#task-list')
taskele.addEventListener('click', function (e){
    let targetel=e.target
    if(targetel.classList.contains('btn-close'))
    {
        let act=targetel.parentElement.parentElement
        let selctedText=act.innerText
        let taskList=localStorage.getItem('tasks')?JSON.parse(localStorage.getItem('tasks')):[];
        taskList=taskList.filter(function(task)
        {  
            return task!==selctedText
        })
        localStorage.setItem('tasks',JSON.stringify(taskList));
        displayTasks();
        if(taskList.length===0)
        {
            taskele.innerHTML='';
        }
    }


    

})